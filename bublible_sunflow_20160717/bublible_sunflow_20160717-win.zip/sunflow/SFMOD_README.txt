Just put everything from "bublible_sunflow_201*" folder into Bluerender's main directory and let overwrite any file it asks you to.



regards

bublible