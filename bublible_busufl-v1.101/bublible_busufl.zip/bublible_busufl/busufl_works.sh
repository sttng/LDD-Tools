#!/bin/sh
cp busufl_works.sh busufl.sh
export JAVA_HOME="/Library/Internet Plug-Ins/JavaAppletPlugin.plugin/Contents/Home"

java -Xmx2G -server -jar DATA

@if %errorlevel% neq 0 pause


rem #DbLifDirectory=/Users/username/Library/Application Support/LEGO Company/LEGO Digital Designer/db.lif
rem #LastDirectory=/Users/username/Documents/Lego Creations/Models
rem #BsfmAutoSave=true
rem #HeapSize=2G
rem #SmallMeshTriangles=false
rem #UseHqBricks=true
rem #FlushTextureCache=false
rem #BsfmAutoClosePrevWin=true
rem #MainWindowPosition=966,180
rem #RenderWindowPosition=0,0
rem #FirstRun=false
